from PyQt6.QtWidgets import (
   QPushButton,
   QLabel,
   QLineEdit,
   QFrame,
   QWidget,
   QVBoxLayout,
   QHBoxLayout,
)
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QPixmap
from ui.styles import STYLES
from utils.file_utils import resource_path

class UIFactory:
   # =========================
   # BUTTON
   # =========================
   @staticmethod
   def button(text: str, callback, style_key: str = "button", width: int = None, height: int = None) -> QPushButton:
       """Standard clickable button."""
       btn = QPushButton(text)
       btn.setCursor(Qt.CursorShape.PointingHandCursor)
       if height:
           btn.setFixedHeight(height)
       if width:
           btn.setFixedWidth(width)
       btn.setStyleSheet(STYLES.get(style_key))
       btn.clicked.connect(callback)
       return btn
   
    # =========================
   # IMAGE
   # =========================
   @staticmethod
   def image( image_path: str, width: int = None, height: int = None, fixed_width: int = None, fixed_height: int = None) -> QLabel:
        """Standard image label."""
        
        label = QLabel()
        label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        label.setStyleSheet("""
            QLabel {
                border: none;
                background: transparent;
            }
        """)

        pixmap = QPixmap(image_path)

        if not pixmap.isNull() and (width or height):
            pixmap = pixmap.scaled(
                width or pixmap.width(),
                height or pixmap.height(),
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation
            )
        label.setPixmap(pixmap)
        if fixed_width:
            label.setFixedWidth(fixed_width)
        if fixed_height:
            label.setFixedHeight(fixed_height)

        return label
   
   # =========================
   # LABEL
   # =========================
   @staticmethod
   def label(
    text: str,

    # Preset styles
    style_key: str | None = None,

    # Layout
    align: str = "left",
    word_wrap: bool = False,

    # Typography
    font_size: int = 12,
    color: str = 'black',
    font_weight: str = "normal",
    italic: bool = False,
    underline: bool = False,

    # Container styling
    background: str = "transparent",
    border: str = "none",
    radius: int = 0,
    padding: int = 0,
    margin: int = 0,

    # Sizing
    width: int | None = None,
    height: int | None = None,

    # Behavior
    selectable: bool = False,
    link: bool = False,
) -> QLabel:
    """
    Standard reusable QLabel builder.
    """
    _ALIGN_MAP = {
        "left":   Qt.AlignmentFlag.AlignLeft,
        "center": Qt.AlignmentFlag.AlignCenter,
        "right":  Qt.AlignmentFlag.AlignRight,
    }
    lbl = QLabel(text)
    lbl.setAlignment(_ALIGN_MAP.get(align.lower(), Qt.AlignmentFlag.AlignCenter))
    lbl.setWordWrap(word_wrap)
    styles = []
    if style_key:
        styles.append(STYLES.get(style_key, ""))
    if font_size:
        styles.append(f"font-size: {font_size}px;")
    if color:
        styles.append(f"color: {color};")
    if font_weight:
        styles.append(f"font-weight: {font_weight};")
    if italic:
        styles.append("font-style: italic;")
    if underline:
        styles.append("text-decoration: underline;")
    if background:
        styles.append(f"background: {background};")
    if border:
        styles.append(f"border: {border};")
    if selectable:
        lbl.setTextInteractionFlags(
            Qt.TextInteractionFlag.TextSelectableByMouse |
            Qt.TextInteractionFlag.TextSelectableByKeyboard
        )
    if link:
        lbl.setTextInteractionFlags(Qt.TextInteractionFlag.TextBrowserInteraction)
        lbl.setOpenExternalLinks(True)
        
    lbl.setStyleSheet(" ".join(styles))
    return lbl

   # =========================
   # INPUT
   # =========================
   @staticmethod
   def input(placeholder: str = "", password: bool = False, style: str = "payroll_input") -> QLineEdit:
       """Standard text input. Set password=True for masked input."""
       field = QLineEdit()
       field.setPlaceholderText(placeholder)
       field.setStyleSheet(STYLES.get(style))
       if password:
           field.setEchoMode(QLineEdit.EchoMode.Password)
       return field
   
   # =========================
   # IMAGE
   # =========================
   @staticmethod
   def image(asset_path: str, w: int = 200, h: int = 200) -> QLabel:
       """Scaled image from assets folder."""
       lbl = QLabel()
       lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
       pixmap = QPixmap(resource_path(asset_path))
       if not pixmap.isNull():
           lbl.setPixmap(
               pixmap.scaled(
                   w, h,
                   Qt.AspectRatioMode.KeepAspectRatio,
                   Qt.TransformationMode.SmoothTransformation
               )
           )
       return lbl
   
   # =========================
   # DIVIDER
   # =========================
   @staticmethod
   def divider() -> QFrame:
       """Horizontal line divider."""
       line = QFrame()
       line.setFrameShape(QFrame.Shape.HLine)
       line.setFrameShadow(QFrame.Shadow.Sunken)
       line.setStyleSheet("color: rgba(0, 0, 0, 0.15);")
       return line
   
   # =========================
   # CARD
   # =========================
   @staticmethod
   def card(object_name: str = "card", min_height: int = 150) -> tuple[QFrame, QVBoxLayout]:
       """
       Rounded content card.
       Returns (frame, layout) so caller can add widgets to layout.
       Usage:
           card, layout = UIFactory.card()
           layout.addWidget(some_widget)
       """
       frame = QFrame()
       frame.setObjectName(object_name)
       frame.setMinimumHeight(min_height)
       frame.setStyleSheet(f"""
           #{object_name} {{
               background: rgba(255, 255, 255, 100);
               border: 1px solid rgba(255, 255, 255, 220);
               border-radius: 20px;
           }}
       """)
       layout = QVBoxLayout()
       frame.setLayout(layout)
       return frame, layout
   
   # =========================
   # BUTTON ROW
   # =========================
   @staticmethod
   def button_row(
       buttons: list[tuple], 
       width: int = None, 
       height: int = None, 
       spacing: int = 10, 
       margin: tuple[int, int, int, int] = (10, 10, 10, 10) 
       ) -> tuple[QWidget, QHBoxLayout]:
       """
       Horizontal row of buttons.
       buttons = list of (text, callback, style_key)
       style_key is optional, defaults to 'button'.
       Usage:
           row, layout = UIFactory.button_row([
               ("Payroll", on_payroll, "payroll_button"),
               ("Checker", on_checker),
               ("Settings", on_settings),
           ])
       """
       container = QWidget()
       layout = QHBoxLayout()
       layout.setContentsMargins(*margin)
       layout.setSpacing(spacing)
       container.setLayout(layout)
       for item in buttons:
           text, callback = item[0], item[1]
           style_key = item[2] if len(item) > 2 else "button"
           layout.addWidget(UIFactory.button(text, callback, style_key, width=width, height=height))

       return container, layout
   
   # =========================
   # BUTTON COLUMN
   # =========================
   @staticmethod
   def button_column(
       buttons: list[tuple], 
       width: int = None, 
       height: int =None, 
       spacing: int = 10, 
       margin: tuple[int, int, int, int] = (10, 10, 10, 10) 
       ) -> tuple[QWidget, QHBoxLayout]:
       """
       Vertical stack of buttons.
       buttons = list of (text, callback, style_key)
       style_key is optional, defaults to 'button'.
       Usage:
           col, layout = UIFactory.button_column([
               ("DarwinBox", on_darwin, "payroll_button"),
               ("Sprout",    on_sprout, "payroll_button"),
           ])
       """
       container = QWidget()
       layout = QVBoxLayout()
       layout.setContentsMargins(*margin)
       layout.setSpacing(spacing)
       container.setLayout(layout)
       for item in buttons:
           text, callback = item[0], item[1]
           style_key = item[2] if len(item) > 2 else "button"
           layout.addWidget(UIFactory.button(text, callback, style_key, width=width, height=height))
           
       return container, layout
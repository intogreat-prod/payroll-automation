
def parse_status_code(code):
        if "|" in code:
            file_name = code.split("|")[0]
            status_code = code.split("|")[1]
        else:
            status_code = code
            file_name = ""

        return file_name, status_code


PAYROLL_STATUSES = {

    # -----------------------
    # SUCCESS
    # -----------------------
    "unmand_success": "Unmand automation started successfully.",
    "file_success": "Files uploaded successfully.",

    # -----------------------
    # FILE ERRORS
    # -----------------------
    "file_exceed_error": "Number of files exceeds the expected limit. Please verify your upload.",
    "no_file_error": "No files selected — aborting upload.",
    "sensitivity_error": "Payroll Headers and Premium.xlsx sensitivity or password protection issue detected.",
    "date_format_error": "Date format error detected in {file_name}",
    "not_found_error": "{file_name} - not found.",
    "missing_id_error": "{file_name} - Missing row 1 header.",
    "missing_total_error": "Current Payroll has missing Total in Employee ID Column",
    "upload_sp_error": "Encountered error when trying to upload the files to Sharepoint. Contact Automation Team.",

    # -----------------------
    # ID / VERSION ERRORS
    # -----------------------
    "id_error": "ID number not found in previous records.",
    "version_duplicate_error": "This version number already exists.",
    "id_missing_error": "Version number provided but ID number is missing.",
    "version_missing_error": "ID number provided but version number is missing.",
    "version_input_error": "Invalid version format. Please use a format like v1, v2, etc.",

    # -----------------------
    # CONFIGURATION ERRORS
    # -----------------------
    "premium_download_error": "Payroll Headers and Premium.xlsx download error. Please check the location.",
    "new_headers_error": "New headers detected. Please update Payroll Headers in Settings before proceeding.",

    # -----------------------
    # UNMAND STATUS
    # -----------------------
    "unmand_init_error": "Failed to start Unmand. Please contact Automation Team.",
    "unmand_init_success": "Unmand initiated successfully. {file_name}",
    "unmand_status_error": "Unmand encountered an error. Please check your inbox for details.",
    "unmand_status_success": "Unmand automation completed successfully. Please verify the generated output.",
    "unmand_status_pending_error": "Unmand is still processing. Please check again shortly."
}

SETTINGS_STATUSES = {

    # -----------------------
    # SUCCESS
    # -----------------------
    "deminimis_save_success": "Deminimis saved successfully",
    "add_user_success": "User added successfully.",

    # -----------------------
    # GENERAL ERROR
    # -----------------------
    "deminimis_save_error": "Failed to save deminimis. Please contact the Automation Team.",
    "add_user_error": "Failed to add user. Please contact the Automation Team.",
    "add_user_email_error": "User added. Welcome email not sent. Please contact the Automation Team.",

    # -----------------------
    # VALIDATION ERRORS
    # -----------------------
    "empty_error": "You did not enter an email address.",
    "duplicate_user": "User already granted access. Please check the users above.",
    "error_email": "Invalid email format. Please enter a valid email address.",
    "error_value": "Invalid input value. Please check your entry and try again."
}

CHECKER_STATUSES = {

    # -----------------------
    # SUCCESS
    # -----------------------
    "file_success": "Files added successfully.",
    "validated_success": "Checker validation completed successfully.",

    # -----------------------
    # FILE ERRORS
    # -----------------------
    "no_file_error": "No files selected — aborting upload.",
    "file_number_error": "Invalid number of files. Please ensure all required files are included.",
    "missing_header_error": "{file_name} - Missing Row 1 Header",
    "missing_total_error": "{file_name} has missing Total in Employee ID Column",

    # -----------------------
    # MISSING FILES
    # -----------------------
    "unmand_error": "Unmand Checker file not found.",
    "manual_error": "Manual Checker file not found.",

    # -----------------------
    # CONFIGURATION ERRORS
    # -----------------------
    "premium_download_error": "Payroll Headers and Premium.xlsx download error. Please check the location.",
    "new_headers_error": "New headers detected. Please update Payroll Headers in Settings before proceeding.",


    # -----------------------
    # VALIDATION ERRORS
    # -----------------------
    "sensitivity_error": "File sensitivity or password protection issue detected."
}
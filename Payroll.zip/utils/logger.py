import datetime
import traceback
from pathlib import Path
from colorama import Fore, Style
import logging


class Logger:

    def __init__(self, app_data_path, session_id=None):

        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        session_id = session_id or timestamp

        self.log_file = (
            Path(app_data_path) / "data" / "logs" / f"logs_{session_id}.log"
        )

        self.log_file.parent.mkdir(parents=True, exist_ok=True)

        # optional: python logging fallback
        logging.basicConfig(
            filename=str(self.log_file),
            level=logging.INFO,
            format="%(asctime)s - %(levelname)s - %(message)s"
        )

    def log(self, message, level="INFO", error=None):

        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        level = level.upper()

        color_map = {
            "INFO": Fore.GREEN,
            "WARNING": Fore.YELLOW,
            "ERROR": Fore.RED
        }

        color = color_map.get(level, Fore.WHITE)

        log_entry = f"[{timestamp}] [{level}] {message}"

        # console
        print(color + log_entry + Style.RESET_ALL)

        trace = ""

        if error:
            trace = traceback.format_exc()
            print(Fore.RED + trace + Style.RESET_ALL)

        # file
        with open(self.log_file, "a", encoding="utf-8") as f:
            f.write(log_entry + "\n")
            if trace:
                f.write(trace + "\n")

    # =========================
    # CONVENIENCE METHODS
    # =========================

    def info(self, msg):
        self.log(msg, "INFO")

    def warning(self, msg):
        self.log(msg, "WARNING")

    def error(self, msg, error=None):
        self.log(msg, "ERROR", error)
"""
file_manager.py
...
"""
from json import load
import os
import shutil
import datetime
import requests
from utils.file_utils import app_data_path
from services.sharepoint_service import SharePointService
from dotenv import load_dotenv

class FileManager:
    def __init__(self, log, managed_folders: list,sp_base_url: str = None ):
        self.log         = log
        self.sp_base_url = os.getenv('SP_BASE_URL')
        self._data_root    = os.path.join(app_data_path(), "data")
        self._archive_root = os.path.join(self._data_root, "archive")

        load_dotenv()

        self.managed_folders = managed_folders
    # ===================================================================
    # 1. SORT AND ARCHIVE  —  call on every app open
    # ===================================================================
    def sort_and_archive(self) -> dict:

        self.log.info("FileManager: Starting sort-and-archive")
        today_str = datetime.datetime.now().strftime("%Y-%m-%d")
        counts    = {"moved": 0, "skipped": 0, "failed": 0}

        for folder_name in self.managed_folders:
            folder_path = os.path.join(self._data_root, folder_name)
            if not os.path.exists(folder_path):  
                self.log.info(f"FileManager: Folder not found, skipping — {folder_path}")
                continue
            
            self.log.info(f"FileManager: Scanning '{folder_name}'")

            for file_name in os.listdir(folder_path):
                file_path = os.path.join(folder_path, file_name)

                if not os.path.isfile(file_path):
                    continue

                file_date = self._parse_file_date(file_name)
                if file_date is None:
                    self.log.info(f"FileManager: Cannot parse date, leaving in place — {file_name}")
                    counts["skipped"] += 1
                    continue

                if file_date.strftime("%Y-%m-%d") == today_str:
                    counts["skipped"] += 1
                    continue

                target_dir = os.path.join(
                    self._archive_root,
                    file_date.strftime("%Y"),
                    file_date.strftime("%m"),
                    file_date.strftime("%d"),
                    folder_name,
                )
                
                counts["moved" if self._move_file(file_path, target_dir, file_name) else "failed"] += 1
        
        self.log.info(
                f"FileManager: Archive complete — "
                f"moved: {counts['moved']} | skipped: {counts['skipped']} | failed: {counts['failed']}"
            )
        
        return counts
    
    # ===================================================================
    # 2. UPLOAD LOG  —  call on close and on unhandled error
    # ===================================================================
    def upload_log(self, state: dict) -> bool:
        self.log.info("FileManager: Starting log upload to SharePoint")
        config = state['config']

        if not self.sp_base_url:
            self.log.warning("FileManager: SP_BASE_URL not set — skipping")
            return False
        
        if not state['token']:
            self.log.warning("FileManager: No token — skipping")
            return False
        
        log_folder = config.get("log_folder") if config else None
        if not log_folder:
            self.log.warning("FileManager: 'log_folder' missing from config — skipping")
            return False
        
        log_file_path = self._resolve_log_file()
        if not log_file_path:
            self.log.warning("FileManager: Could not resolve log file — skipping")
            return False
        
        try:
            with open(log_file_path, "r", encoding="utf-8") as f:
                content = f.read()
        except Exception as e:
            self.log.warning(f"FileManager: Failed to read log file — {e}", error=e)
            return False
        
        log_file_name = os.path.basename(log_file_path)
        today_str     = datetime.datetime.now().strftime("%Y/%m/%d")
        url = f"{self.sp_base_url}root:/{log_folder}/{today_str}/{log_file_name}:/content"
        content_type = "text/plain"
        self.log.info(f"FileManager: Uploading '{log_file_name}' → SharePoint")
        
        try:
            sharepoint = SharePointService(state['token'])
            response = sharepoint.put_file(url=url, data=content, content_type=content_type)

        except requests.exceptions.Timeout:
            self.log.warning("FileManager: Upload timed out")
            return False
        
        except Exception as e:
            self.log.warning(f"FileManager: Upload request failed — {e}", error=e)
            return False
        
        if 200 <= response.status_code < 300:
            self.log.info(f"FileManager: Upload successful — HTTP {response.status_code}")
            return True
        
        self.log.warning(f"FileManager: Upload failed — HTTP {response.status_code} | {response.text[:200]}")
        return False
    # ===================================================================
    # PRIVATE HELPERS
    # ===================================================================
    def _parse_file_date(self, file_name: str):
        try:
            base  = os.path.splitext(file_name)[0]
            parts = base.split("_")
            return datetime.datetime.strptime(parts[-2] + parts[-1], "%Y%m%d%H%M%S")
        
        except Exception:
            return None
        
    def _move_file(self, src: str, target_dir: str, file_name: str) -> bool:
        try:
            os.makedirs(target_dir, exist_ok=True)
            shutil.move(src, os.path.join(target_dir, file_name))
            self.log.info(f"FileManager: Moved '{file_name}' → {target_dir}")
            return True
        
        except Exception as e:
            self.log.warning(f"FileManager: Failed to move '{file_name}' — {e}", error=e)
            return False
        
    def _resolve_log_file(self) -> str | None:
        logs_dir  = os.path.join(self._data_root, "logs")
        today_str = datetime.datetime.now().strftime("%Y-%m-%d")
        if not os.path.exists(logs_dir):
            return None
        for file_name in os.listdir(logs_dir):
            file_path = os.path.join(logs_dir, file_name)
            if os.path.isfile(file_path):
                date = self._parse_file_date(file_name)
                if date and date.strftime("%Y-%m-%d") == today_str:
                    return file_path
        return None
"""
error_handler.py
----------------
Global uncaught exception handler for the Payroll Automation app.
Catches any unhandled exception that would otherwise crash the app,
then:
 1. Logs the full traceback
 2. POSTs the error report to a webhook / error-tracking API
 3. Shows a user-friendly system error dialog in the UI
Usage:
   from utils.error_handler import register_global_handler
   register_global_handler(log, webhook_url, api_token)
"""
import os
import sys
import traceback
from datetime import datetime
from dotenv import load_dotenv
from PyQt6.QtWidgets import QMessageBox, QApplication

from services.power_automate_service import PowerAutomateService
from utils.file_manager import FileManager


# ===================================================================
# PUBLIC API
# ===================================================================
def register_global_handler(log, str = None, state: dict = None, body=None, file_manager=None):
    """
    Call once at app startup (before mainloop).
    Args:
        log:         Your Logger instance from utils/logger.py
        webhook_url: Optional URL to POST error reports to
        api_token:   Optional Bearer token for the webhook
    """
    def _handler(exc_type, exc_value, exc_tb):
        # Let KeyboardInterrupt pass through normally
        if issubclass(exc_type, KeyboardInterrupt):
            sys.__excepthook__(exc_type, exc_value, exc_tb)
            return
        tb_str = "".join(traceback.format_exception(exc_type, exc_value, exc_tb))
        # 1 — Log it
        _log_error(log, exc_type, exc_value, tb_str)
        # 2 — Report it
        if state:
            group_id = state['config']['teams']['id']
            user = f"{state['name']} | {state['email']}"
            webhook_url = state['config']['teams']['flow']
            _report_error(webhook_url, group_id, user, exc_type, exc_value, tb_str)
        # 3 — Show UI dialog
        if body:
            body.show_system_error(exc_type, exc_value, tb_str)
        else:     
                _show_error_dialog(exc_type, exc_value, tb_str)

        # 4 — Upload logs
        if file_manager:
            file_manager.upload_log(state)

    sys.excepthook = _handler

# ===================================================================
# INTERNAL STEPS
# ===================================================================
def _log_error(log, exc_type, exc_value, tb_str: str):
    log.error(
        f"UNHANDLED EXCEPTION — {exc_type.__name__}: {exc_value}\n{tb_str}"
    )

def _report_error(webhook_url: str, group_id, user, exc_type, exc_value, tb_str: str):
   
    load_dotenv()
    
    payload = {
                "Automation": f"⚠️ {os.getenv('app')} - {os.getenv('ENVT')} - Payroll Automation ⚠️",
                "GroupID": group_id,
                "Image": "",
                "DateTime": datetime.now().strftime("%Y-%m-%d %I:%M:%S %p - %A"),
                "User": user,
                "Screen/Action": "Local App",
                "Error": True,
                "Link": "",
                "Text": f"""
                    <b>Type:</b> {exc_type.__name__}<br>
                    <b>Message:</b> {str(exc_value)}<br>
                    <b>Traceback:</b><br>
                    <pre>{tb_str}</pre>
                    """
                
            }
    
    power_automate = PowerAutomateService()

    #response = power_automate.start(webhook_url, payload)
#
    #if not str(response.status_code).startswith("2"):
    #       print(f"[error_handler] Webhook responded with {response.status_code}")


def _show_error_dialog(exc_type, exc_value, tb_str: str):
   # Ensure a QApplication exists before showing a dialog
   app = QApplication.instance()
   if not app:
       return
   dialog = QMessageBox()
   dialog.setWindowTitle("Unexpected Error")
   dialog.setIcon(QMessageBox.Icon.Critical)
   dialog.setText(
       "<b>An unexpected error occurred.</b><br><br>"
       "The error has been logged and reported to the Automation Team.<br>"
       "Please restart the application."
   )
   dialog.setDetailedText(
       f"{exc_type.__name__}: {exc_value}\n\n{tb_str}"
   )
   dialog.setStandardButtons(QMessageBox.StandardButton.Ok)
   dialog.exec()
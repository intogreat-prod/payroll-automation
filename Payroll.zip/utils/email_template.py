
WELCOME_EMAIL = """
    <html>
    <head>
        <meta charset='UTF-8'>
        <meta name='viewport' content='width=device-width, initial-scale=1.0'>
        <title>CaseFlow</title>
    </head>

    <body style='margin:0;padding:0;background-color:#1E1E1E;font-family:Arial,sans-serif;color:#333;'>

        <!-- HEADER -->
        <div style='margin-top:15px;'>
            <img src='https://4867849.fs1.hubspotusercontent-na1.net/hub/4867849/hubfs/Branding/RGB_Intogreat__White%201.png?t=1740109657770&width=860' 
                style='width:100%;max-width:700px;border-radius:10px;margin:10px auto;display:block;'>
        </div>

        <!-- BODY -->
        <div style='background-color:#ffffff;margin:30px auto;padding:30px;border-radius:8px;width:90%;max-width:900px;
                    box-shadow:0 2px 8px rgba(0,0,0,0.1);'>

            <p>Hi <b>Team,</b></p>

            <p>Welcome to <b>Payroll Automation</b>!</p>

            <p style='margin-top:20px;'>
                <b>{user}</b> has added you as a user of the Payroll Automation system. Let's get you set up.
            </p>

            <p style='margin-top:15px;'>
                <b>Getting Started:</b>
            </p>

            <p>
                1. Please download and install the application from the designated folder.<br>
                2. If the application does not open or you encounter issues, please contact the Automation Team for assistance.<br>
                3. Refer to the User Guide available <a href='#' target='_blank'>here</a>.<br>
            </p>

        </div>

        <p style='font-size:12px;color:#777;text-align:center;margin:20px 0;'>
            DO NOT REPLY — This is an automated email.
        </p>

    </body>
    </html>
    """
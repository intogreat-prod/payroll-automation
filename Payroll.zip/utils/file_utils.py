from pathlib import Path
import os
import sys
from dotenv import load_dotenv

load_dotenv()


def app_data_path():
    """
    Returns user-safe app data directory.
    Used for logs, cache, exports, etc.
    """
    path = Path.home() / "Documents" / "Automations" / os.getenv('loc')
    path.mkdir(parents=True, exist_ok=True)
    return path


def logs_path():
    path = app_data_path() / "data" / "logs"
    path.mkdir(parents=True, exist_ok=True)
    return path


def archive_path():
    path = app_data_path() / "data" / "archive"
    path.mkdir(parents=True, exist_ok=True)
    return path


def validation_path():
    path = app_data_path() / "data" / "validation"
    path.mkdir(parents=True, exist_ok=True)
    return path

def resource_path(relative_path):
    base_path = getattr(
        sys,
        "_MEIPASS",
        os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # 👈 FIX
    )
    return os.path.join(base_path, relative_path)

import requests


def internet_available():
    """
    Checks basic internet connectivity.
    Returns True if reachable, False otherwise.
    """

    try:
        requests.get("https://www.google.com", timeout=3)
        return True

    except Exception:
        return False

import requests
import json
import os
from dotenv import load_dotenv

load_dotenv()

class ConfigService:
    def __init__(self):
        base_url   = os.getenv("SP_BASE_URL")
        config_loc = os.getenv("config_loc")
        
        self.config_url = f"{base_url}{config_loc}"

    def get(self, token):
        headers = {
            "Authorization": f"Bearer {token}"
        }

        response = requests.get(self.config_url, headers=headers)

        if response.status_code == 200:
            return response

        raise Exception("Failed to load config")

    def update(self, config_data, token):
        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json"
        }

        response = requests.put(
            self.config_url,
            headers=headers,
            data=json.dumps(config_data, indent=4)
        )

        return response

import requests
import json

class OutlookService():
    def __init__(self):
        pass


    def send(self, url, payload, token, content: str = "application/json"):
        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": content
        }

        response = requests.post(url, headers=headers, data=json.dumps(payload), timeout=5)

        return response

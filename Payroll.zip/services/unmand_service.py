import requests
import json


class UnmandService:
    def __init__(self, webhook_url, token):
        self.webhook_url = webhook_url
        self.token = TokenAuth(token)

    def start_process(self, payload):
        response = requests.post(
            self.webhook_url,
            json=payload,
            auth=self.token
        )

        return response

    def check_status(self, task_guid):
        url = f"https://swarm.unmand.app/tasks/{task_guid}"

        response = requests.get(
            url,
            auth=self.token
        )

        if not str(response.status_code).startswith("2"):
            raise UserWarning(f"Unable to check Unmand Status - {json.dumps(response)}")
        else:

            status = json.loads(response.text)['task']['status']

            if status == "SUCCESS":
                return "unmand_status_success"
            elif status in ["ERROR", "FAILURE"]:
                return 'unmand_status_error'
            elif status in ["PENDING", "QUEUED", "RUNNING"]:
                return 'unmand_status_pending_error'

class TokenAuth(requests.auth.AuthBase):
    """Implements a custom authentication scheme."""

    def __init__(self, token: str):
        self.unmand_token: str = token

    def __call__(self, r: requests.PreparedRequest):
        """Attach an API token to a custom auth header."""
        r.headers['Authorization'] = self.unmand_token
        return r
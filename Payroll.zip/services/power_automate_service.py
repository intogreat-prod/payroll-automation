import requests
import json

class PowerAutomateService():
    def __init__(self):
        pass


    def start(self, url, payload, content: str = "application/json"):
        headers = {
            "Content-Type": content
        }

        response = requests.post(url, headers=headers, data=json.dumps(payload), timeout=5)

        return response

"""
msal_service.py
---------------
Handles Microsoft Authentication Library (MSAL) login.

Receives a Logger instance from the Orchestrator — no print() calls here.
"""

import os

import msal
import requests
from dotenv import load_dotenv
from msal_extensions import PersistedTokenCache, build_encrypted_persistence
from PyQt6.QtCore import QThread, pyqtSignal

from utils.file_utils import app_data_path


# ---------------------------------------------------------------------------
# Background worker — runs the blocking device-flow polling off the UI thread
# ---------------------------------------------------------------------------

class LoginWorker(QThread):
    finished = pyqtSignal(dict)

    def __init__(self, app, scopes):
        super().__init__()
        self.app    = app
        self.scopes = scopes

    def run(self):
        flow = self.app.initiate_device_flow(scopes=self.scopes)

        if "user_code" not in flow:
            self.finished.emit({"error": "Failed to create device flow"})
            return

        # Emit the code immediately so the UI can show it while we wait
        self.finished.emit({
            "type":      "code",
            "user_code": flow["user_code"],
            "url":       flow["verification_uri"],
            "message":   flow["message"],
        })

        # Blocks this thread (not the UI) until the user completes auth
        result = self.app.acquire_token_by_device_flow(flow)
        self.finished.emit({"type": "result", "result": result})


# ---------------------------------------------------------------------------
# MSALService
# ---------------------------------------------------------------------------

class MSALService:

    SCOPES = ["User.Read", "Sites.Read.All", "Files.ReadWrite.All", "Mail.Send"]

    def __init__(self, log):
        self.log = log

        # Callbacks wired by Orchestrator
        self.on_login_complete = None
        self.on_device_code    = None
        self.error_login       = None

        self.token  = None
        self.worker = None

        load_dotenv()
        client_id  = os.getenv("CLIENT_ID")
        tenant_id  = os.getenv("TENANT_ID")
        authority  = f"https://login.microsoftonline.com/{tenant_id}"

        self.cache = self._load_cache()
        self.app   = msal.PublicClientApplication(
            client_id, authority=authority, token_cache=self.cache
        )

        self.log.info("MSALService initialised")

    # ===================================================================
    # PUBLIC
    # ===================================================================

    def start_login(self):
        accounts = self.app.get_accounts()
        result   = None

        # 1. Silent login (cached token)
        if accounts:
            self.log.info("Trying silent login from token cache...")
            result = self.app.acquire_token_silent(self.SCOPES, account=accounts[0])

        # 2. Interactive login
        if not result:
            self.log.info("Silent login failed — falling back to interactive login")
            result = self.app.acquire_token_interactive(self.SCOPES)

        # 3. Success on either path
        if result and "access_token" in result:
            self._handle_result(result)
            return

        # 4. Last resort: device-code flow on background thread
        self.log.info("Interactive login unavailable — starting device code flow")
        self.worker = LoginWorker(self.app, self.SCOPES)
        self.worker.finished.connect(self._on_worker_payload)
        self.worker.start()

    # ===================================================================
    # PRIVATE
    # ===================================================================

    def _on_worker_payload(self, payload):
        """Slot that receives both the device-code dict and the final result."""

        if payload.get("type") == "code":
            self.log.info(f"Device code ready: {payload.get('user_code')}")
            if self.on_device_code:
                self.on_device_code(payload)
            return

        if payload.get("type") == "result":
            self._handle_result(payload.get("result", {}))
            return

        # Unexpected shape
        self.log.error(f"Unexpected worker payload: {payload}")

    def _handle_result(self, result):
        """Process a flat MSAL result dict (access_token or error)."""

        if "access_token" in result:
            self.token = result["access_token"]

            try:
                email, name = self._fetch_user_profile()
            except Exception as e:
                self.log.error(f"Failed to fetch user profile: {e}", error=e)
                if self.error_login:
                    self.error_login(str(e))
                return

            self.log.info(f"Token acquired for {email}")

            if self.on_login_complete:
                self.on_login_complete(email, name, self.token)

        else:
            error = (
                result.get("error_description")
                or result.get("error")
                or "Unknown MSAL error"
            )
            self.log.error(f"Token acquisition failed: {error}")
            if self.error_login:
                self.error_login(error)

    def _fetch_user_profile(self):
        """Call MS Graph /me to get email and display name."""
        res = requests.get(
            "https://graph.microsoft.com/v1.0/me",
            headers={"Authorization": f"Bearer {self.token}"},
        )
        if res.status_code == 200:
            data = res.json()
            return data.get("mail"), data.get("displayName")

        raise RuntimeError(f"Graph /me returned HTTP {res.status_code}: {res.text}")

    def _load_cache(self):
        cache_path = app_data_path() / "data" / "auth" / "msal" / "token_cache.bin"
        cache_path.parent.mkdir(parents=True, exist_ok=True)

        persistence = build_encrypted_persistence(str(cache_path))
        return PersistedTokenCache(persistence)

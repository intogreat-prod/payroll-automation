import requests

class SharePointService:
    def __init__(self, token):
        self.token = token

    def get(self, url):
        headers = {
            "Authorization": f"Bearer {self.token}"
        }

        response = requests.get(url, headers=headers)
        return response

    def put_file(self, url, data, content_type="application/json"):
        headers = {
            "Authorization": f"Bearer {self.token}",
            "Content-Type": content_type
        }

        response = requests.put(url, headers=headers, data=data)
        return response

    def post_json(self, url, payload):
        headers = {
            "Authorization": f"Bearer {self.token}",
            "Content-Type": "application/json"
        }

        response = requests.post(url, headers=headers, json=payload)
        return response
    


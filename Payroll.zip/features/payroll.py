import os
import io
import json
import pandas as pd
from dotenv import load_dotenv
from datetime import datetime
from difflib import get_close_matches
import msoffcrypto

from PyQt6.QtWidgets import QFileDialog
from ui.statuses import *
from services.sharepoint_service import SharePointService



class PayrollFeature:
    def __init__(self, log, main_window):
        self.log = log
        self.main_window = main_window

        self.on_result = None
        self.uploaded_files = None

        load_dotenv()


    def prepare_payroll_files(self, files, payroll_metadata, source, token):
    # ===================================================================
    # GET PAYROLL HEADERS FILE
    # ===================================================================
        self.log.info("PayrollFeature: Preparing payroll files")

        # Initialise SharePoint service
        self._sharepoint = SharePointService(token)

        base_url    = os.getenv("SP_BASE_URL")
        headers_loc = payroll_metadata['headers_loc']
        url         = f"{base_url}{headers_loc}"

        self.log.info(f"PayrollFeature: Downloading payroll headers from SharePoint")
        response = self._sharepoint.get(url)

        if not str(response.status_code).startswith("2"):
            self.log.warning(f"PayrollFeature: Headers download failed — HTTP {response.status_code}")
            self._emit_result('premium_download_error')
            return

        # Parse headers from the correct sheet based on source
        try:
            excel_file = io.BytesIO(response.content)
            sheet_name = "Sprout Payroll Headers" if source == "Sprout" else "DarwinBox Payroll Headers"
            self.log.info(f"PayrollFeature: Reading headers sheet '{sheet_name}' for source '{source}'")
            df = pd.read_excel(excel_file, sheet_name=sheet_name, header=12, engine="openpyxl")
        except Exception as e:
            self.log.warning(f"PayrollFeature: Failed to read headers file — {e}")
            self._emit_result("sensitivity_error")
            return

        payroll_headers = list(df['Headers'])
        self.log.info(f"PayrollFeature: Loaded {len(payroll_headers)} payroll header(s)")

        # ===================================================================
        # GET FILES FROM USER
        # ===================================================================
        file_paths, _ = QFileDialog.getOpenFileNames(
            self.main_window,
            "Select Excel File",
            "",
            "Excel Files (*.xlsx *.xls)"
        )

        self.log.info(f"PayrollFeature: User selected {len(file_paths)} file(s) — expected up to {len(files)}")

        if not file_paths:
            self.log.info("PayrollFeature: No files selected — aborting upload")
            self._emit_result("no_file_error")
            return

        if len(file_paths) > len(files):
            self.log.warning(f"PayrollFeature: Too many files selected ({len(file_paths)} > {len(files)})")
            self._emit_result("file_exceed_error")
            return

        self.log.info("PayrollFeature: File count validated")

        # ===================================================================
        # PRE-PROCESS AND DECRYPT FILES
        # ===================================================================
        self.log.info("PayrollFeature: Reading and decrypting files")
        dataframes = {}
        year = datetime.now().year

        for file_path in file_paths:
            filename = file_path.split("/")[-1]
            try:
                df = pd.read_excel(file_path, dtype=str)
                dataframes[filename] = df
                self.log.info(f"PayrollFeature: Read OK — {filename}")

            except Exception:
                # Try password decryption
                try:
                    decrypted = io.BytesIO()
                    with open(file_path, "rb") as f:
                        office_file = msoffcrypto.OfficeFile(f)
                        office_file.load_key(password=f"INTOGREAT{year}")
                        office_file.decrypt(decrypted)

                    decrypted.seek(0)
                    df = pd.read_excel(decrypted, dtype=str)
                    dataframes[filename] = df
                    self.log.info(f"PayrollFeature: Decrypted and read OK — {filename}")

                except Exception as e:
                    self.log.warning(f"PayrollFeature: Failed to read or decrypt '{filename}' — {e}")
                    dataframes[filename] = "sensitivity_error"

        # ===================================================================
        # VALIDATE ATTENDANCE DATE FORMAT
        # ===================================================================
        self.log.info("PayrollFeature: Validating attendance date formats")
        for filename, df in dataframes.items():
            if "attendance" in filename.lower() and isinstance(df, pd.DataFrame):
                has_day = df.astype(str).apply(lambda col: col.str.contains("day,", na=False)).any().any()
                if has_day:
                    self.log.warning(f"PayrollFeature: Invalid date format detected in '{filename}'")
                    dataframes[filename] = "date_format_error"

        # ===================================================================
        # CHECK FOR NEW HEADERS
        # ===================================================================
        self.log.info("PayrollFeature: Checking for new/unrecognised headers in payroll register")
        new_headers = {}
        for filename, df in dataframes.items():
            if not isinstance(df, pd.DataFrame):
                continue
            if "payroll register" not in filename.lower():
                continue
            for col in df.columns:
                if col not in payroll_headers and "Unnamed" not in col:
                    new_headers.setdefault(filename, []).append(col)

        # ===================================================================
        # UPLOAD NEW HEADERS (if found) AND STOP
        # ===================================================================
        if new_headers:
            self.log.info(f"PayrollFeature: New headers detected — {new_headers}")

            new_header_file = json.dumps(new_headers, indent=4)
            new_headers_loc = payroll_metadata['new_headers_loc']
            url = f"{base_url}{new_headers_loc}"

            self.log.info(f"PayrollFeature: Uploading new headers to SharePoint — {url}")
            self._sharepoint.put_file(url, new_header_file)

            self.log.info("PayrollFeature: New headers uploaded — notifying user")
            self._emit_result("new_headers_error")
            return

        # ===================================================================
        # UNIFORM EMPLOYEE ID COLUMN NAME
        # ===================================================================
        self.log.info("PayrollFeature: Normalising Employee ID column names")
        expected_ids = payroll_metadata['expected_id_names']

        for file_, content in dataframes.items():
            if not isinstance(content, pd.DataFrame):
                continue

            found = False
            for id_name in expected_ids:
                match = get_close_matches(str(id_name), list(map(str, content.columns)), n=1, cutoff=0.6)
                if match:
                    content.rename(columns={match[0]: "Employee ID"}, inplace=True)
                    self.log.info(f"PayrollFeature: Renamed '{match[0]}' → 'Employee ID' in '{file_}'")
                    found = True
                    break

            if not found:
                self.log.warning(f"PayrollFeature: No Employee ID column found in '{file_}'")
                dataframes[file_] = "missing_header_error"

        # ===================================================================
        # CHECK FOR MISSING REQUIRED FILES
        # ===================================================================
        self.log.info("PayrollFeature: Matching uploaded files against required file list")
        required_files = payroll_metadata['required_files']

        for exp in required_files: 
            best_match = get_close_matches(exp, list(dataframes.keys()),n=1,cutoff=0.5)
            if not best_match:
                self.log.warning(f"PayrollFeature: Required file not found — '{exp}'")
                # Store error directly in dataframes
                dataframes[exp] = "not_found_error"

        # ===================================================================
        # CHECK FOR TOTAL ROW IN CURRENT PAYROLL
        # ===================================================================
        self.log.info("PayrollFeature: Checking for Total row in current payroll")
        for filename, df in dataframes.items():
            if "curr" in filename.lower() and "payroll" in filename.lower():
                if isinstance(df, pd.DataFrame):
                    if not df["Employee ID"].str.contains("total", case=False, na=False).any():
                        self.log.warning(f"PayrollFeature: Missing Total row in Employee ID column — '{filename}'")
                        dataframes[filename] = "missing_total_error"
                    else:
                        self.log.info(f"PayrollFeature: Total row found in '{filename}'")

        # ===================================================================
        # AGGREGATE DEDUCTIONS
        # ===================================================================
        self.log.info("PayrollFeature: Aggregating deduction files by Employee ID")
        for filename, df in dataframes.items():
            if "deduct" in filename.lower() and isinstance(df, pd.DataFrame):
                df["Number/Amount"] = pd.to_numeric(df["Number/Amount"], errors="coerce").fillna(0)
                aggregated = df.groupby("Employee ID", as_index=False).agg({"Number/Amount": "sum"})
                dataframes[filename] = aggregated
                self.log.info(f"PayrollFeature: Aggregated deductions for '{filename}' — {len(aggregated)} unique employee(s)")

        # ===================================================================
        # FLAG ERRORS
        # ===================================================================
        self.log.info("PayrollFeature: Running final error check across all files")
        no_error = True
        error_codes = []

        for file, status in dataframes.items():
            if isinstance(status, pd.DataFrame):
                self.log.info(f"PayrollFeature: '{file}' — OK")
            else:
                self.log.warning(f"PayrollFeature: '{file}' — ERROR: {status}")
                error_codes.append(f"{file}|{status}")
                no_error = False

        if no_error:
            self.log.info("PayrollFeature: All files validated successfully — proceeding to upload")
            self._emit_files(dataframes)
        else:
            self.log.warning(f"PayrollFeature: Validation failed with {len(error_codes)} error(s) — {error_codes}")
            self._emit_result(error_codes)


    def _emit_result(self, codes):
        if not self.on_result:
            return

        if isinstance(codes, (list, tuple)):
            normalized = list(codes)
        else:
            normalized = [codes]

        self.on_result(normalized)

    def _emit_files(self, files):
        if not self.uploaded_files:
            return

        self.uploaded_files(files)

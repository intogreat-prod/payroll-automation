import os
import io
import json
import pandas as pd
from dotenv import load_dotenv
from difflib import get_close_matches
from datetime import datetime
import msoffcrypto

from PyQt6.QtWidgets import QFileDialog
from ui.statuses import *

class CheckerFeature:
    def __init__(self, log, main_window):
        self.log = log
        self.main_window = main_window

        self.on_result = None
        self.uploaded_files = None

        load_dotenv()

    def prepare_checker_files(self, id_names):
        self.log.info("CheckerFeature: Preparing checker files")

            # ===================================================================
        # GET FILES FROM USER
        # ===================================================================
        file_paths, _ = QFileDialog.getOpenFileNames(
            self.main_window,
            "Select Excel File",
            "",
            "Excel Files (*.xlsx *.xls)"
        )

        self.log.info(f"CheckerFeature: User selected {len(file_paths)} file(s) — expected up to {2}")

        if not file_paths:
            self.log.info("CheckerFeature: No files selected — aborting upload")
            self._emit_result("no_file_error")
            return

        if len(file_paths) > 2:
            self.log.warning(f"CheckerFeature: Too many files selected ({len(file_paths)} > {2})")
            self._emit_result("file_exceed_error")
            return

        self.log.info("CheckerFeature: File count validated")


        # ===================================================================
        # PRE-PROCESS AND DECRYPT FILES
        # ===================================================================
        self.log.info("CheckerFeature: Reading and decrypting files")
        dataframes = {}
        year = datetime.now().year

        for file_path in file_paths:
            filename = file_path.split("/")[-1]
            try:
                df = pd.read_excel(file_path, dtype=str)
                dataframes[filename] = df
                self.log.info(f"CheckerFeature: Read OK — {filename}")

            except Exception:
                # Try password decryption
                try:
                    decrypted = io.BytesIO()
                    with open(file_path, "rb") as f:
                        office_file = msoffcrypto.OfficeFile(f)
                        office_file.load_key(password=f"INTOGREAT{year}")
                        office_file.decrypt(decrypted)

                    decrypted.seek(0)
                    df = pd.read_excel(decrypted, dtype=str)
                    dataframes[filename] = df
                    self.log.info(f"CheckerFeature: Decrypted and read OK — {filename}")

                except Exception as e:
                    self.log.warning(f"CheckerFeature: Failed to read or decrypt '{filename}' — {e}")
                    dataframes[filename] = "sensitivity_error"
        # ===================================================================
        # FLAG MISSING FILE
        # ===================================================================
        file_names = [fp.lower() for fp in dataframes]

        unmand_file = any("unmand" in fp for fp in file_names)
        manual_file = any("manual" in fp for fp in file_names)


        if not manual_file:
            self._emit_result('manual_error')
            return

        elif not unmand_file:
            self._emit_result('unmand_error')
            return
        
        # ===================================================================
        # CHECK FOR TOTAL ROW AND RENAME EMPLOYEE ID HEADER
        # ===================================================================
#Expected ID header names
        for file_, content in dataframes.items():
            if isinstance(content, pd.DataFrame):
                found = False

                for id_name in id_names:
                    match = get_close_matches(id_name, list(content.columns), n=1, cutoff=0.6)

                    if match:
                        content.rename(columns={match[0]: "Employee ID"}, inplace=True)
                        found = True
                        break

                if not found:
                    dataframes[file_] = "missing_header_error"

                # After renaming columns
                if "Employee ID" in content.columns:
                    # Convert to string to avoid issues
                    col = content["Employee ID"].astype(str).str.lower()

                    # Check if any value contains 'total'
                    if not col.str.contains("total").any():
                        dataframes[file_] = "missing_total_error"

        # ===================================================================
        # FLAG ERRORS
        # ===================================================================
        self.log.info("CheckerFeature: Running final error check across all files")
        no_error = True
        error_codes = []

        for file, status in dataframes.items():
            if isinstance(status, pd.DataFrame):
                self.log.info(f"CheckerFeature: '{file}' — OK")
            else:
                self.log.warning(f"CheckerFeature: '{file}' — ERROR: {status}")
                error_codes.append(f"{file}|{status}")
                no_error = False

        if no_error:
            self.log.info("CheckerFeature: All files validated successfully — proceeding to upload")
            self._emit_result('file_success')
            self._emit_files(dataframes)
        else:
            self.log.warning(f"CheckerFeature: Validation failed with {len(error_codes)} error(s) — {error_codes}")
            self._emit_result(error_codes)
        

    def _emit_result(self, codes):
        if not self.on_result:
            return

        if isinstance(codes, (list, tuple)):
            normalized = list(codes)
        else:
            normalized = [codes]

        self.on_result(normalized)

    def _emit_files(self, files):
        if not self.uploaded_files:
            return

        self.uploaded_files(files)

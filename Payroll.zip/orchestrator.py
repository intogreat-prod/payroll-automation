"""
orchestrator.py
---------------
Single source of truth for app state and flow control.

Data flow:
  Orchestrator  →  calls body.show_*()  →  Body renders the screen
  Body          →  fires on_* callbacks →  Orchestrator handles the event

The UI (Body) never calls a service directly.
Services never touch the UI directly.
"""
import os
import io
import json
import re
import webbrowser
from datetime import datetime
import pandas as pd
import requests

from ui.main_window import MainWindow
from ui.statuses import *

from services.msal_service import MSALService
from services.sharepoint_service import SharePointService
from services.config_service import ConfigService
from services.unmand_service import UnmandService
from services.power_automate_service import PowerAutomateService
from services.outlook_services import OutlookService

from utils.error_handler import register_global_handler
from utils.file_manager import FileManager
from utils.internet import internet_available
from utils.logger import Logger
from utils.file_utils import app_data_path
from utils.email_template import *

from features.payroll import PayrollFeature
from features.checker import CheckerFeature



class Orchestrator:

    def __init__(self):

        # Logger is created first so every step of startup is captured
        self.log = Logger(app_data_path())

        # ---------------------------------------------------------------
        # App state
        # ---------------------------------------------------------------
        self.state = {
            "source":          None,
            "feature":         None,
            "logged_in":       False,
            "email":           None,
            "name":            None,
            "token":           None,
            "config":          None,
            "folder_name":     None,
            "guid":            None,
            "files":           None,
            "variance_file":   None,
            "version":         'v1',
            "id":              datetime.now().strftime("%Y%m%d_%H%M%S"),
            "month_year":      datetime.now().strftime("%B %Y")
        }
        # ---------------------------------------------------------------
        # User inputs (optional overrides from the UI form)
        # ---------------------------------------------------------------
        self.inputs = {
            "id": None,
            "version": None,
            "user": None
        }

        # ---------------------------------------------------------------
        # Build the window and grab a shortcut to the body
        # ---------------------------------------------------------------
        self.main_window = MainWindow()
        self.body = self.main_window.body
        self.header = self.main_window.header
        self.footer = self.main_window.footer

        # ---------------------------------------------------------------
        # File Manager (sort and archive files)
        # ---------------------------------------------------------------
        self._file_manager = FileManager(self.log, ['validation', 'logs'])
        self._file_manager.sort_and_archive()

        # ---------------------------------------------------------------
        # GLOBAL ERROR HANDLER (SYSTEM ERROR)
        # ---------------------------------------------------------------
        register_global_handler(
            log=self.log,
            state=self.state,
            body=self.body,
            file_manager=self._file_manager
        )
        
        # ---------------------------------------------------------------
        # Wire UI callbacks → Orchestrator handlers
        # ---------------------------------------------------------------
        self.header.on_clicked = self._handle_header_clicks
        self.body.on_clicked = self._handle_body_clicks
        
        self.main_window.show()

        # Features of the app
        self.payroll = PayrollFeature(self.log, self.main_window)
        self.checker = CheckerFeature(self.log, self.main_window)

        # ---------------------------------------------------------------
        # Wire feature callbacks → Orchestrator handlers
        # ---------------------------------------------------------------
        self.payroll.on_result = self._payroll_files_preparation_result
        self.payroll.uploaded_files = self._upload_sp_files

        self.checker.on_result = self._checker_files_preparation_result
        self.checker.uploaded_files = self._generate_validation

        # Services are created lazily (only when needed)
        self._msal       = None
        self._sharepoint = None
        self._unmand     = None
        self._config     = None

        self.SP_BASE_URL = os.getenv('SP_BASE_URL')

        self.log.info("Orchestrator initialised")

    # ===================================================================
    # HANDLE BUTTON CLICKS
    # ===================================================================
    def _handle_body_clicks(self, btn):
        self.log.info(f"Button clicked: {btn}")

        # Button clicks with payload (inputs)
        if isinstance(btn, list):
            if btn[0] == "payroll_upload":
                self.inputs['id'] = btn[1].strip()
                self.inputs['version'] = btn[2].strip()
                self.log.info(f"Payroll upload triggered — ID input: '{self.inputs['id']}' | Version input: '{self.inputs['version']}'")
                self._on_payroll_upload_clicked()

            elif btn[0] == "save_deminimis":
                deminimis = btn[1]
                self._save_deminimis(deminimis)

            elif btn[0] == "add_user":
                email = btn[1]
                self._add_user(email)
            return
    
        # Button clicks only
        if btn == "retry":
            self.log.info("Retry triggered — restarting app flow")
            self.start()

        elif btn == "login":
            self._login()

        elif "source" in btn:
            self._on_source_selected(btn)

        elif "feature" in btn:
            self._on_feature_selected(btn)

        elif btn == "send_unmand":
            self.log.info("Send to Unmand triggered")
            self._start_unmand()

        elif btn == "check_status":
            self.log.info(f"Check Unmand status triggered — GUID: {self.state.get('guid')}")
            self._check_unmand()

        elif btn == "open_new_headers":
            url = self.state['config']['payroll']['new_headers_url']
            self.log.info(f"Opening new headers URL: {url}")
            webbrowser.open(url)

        elif btn == "open_payroll_ouput":
            url = self.state['config']['payroll']['headers_url']
            self.log.info(f"Opening payroll output URL: {url}")
            webbrowser.open(url)

        elif btn == "checker_upload":
            id_names = self.state['config']['payroll']['expected_id_names']
            self.checker.prepare_checker_files(id_names)

        elif btn == "open_checker_output":
            os.startfile(self.state['variance_file'])

        elif btn == "payroll_headers":
            url = self.state['config']['payroll']['headers_url']
            self.log.info(f"Opening Payroll Premium and Headers: {url}")
            webbrowser.open(url)

        elif btn == "nd_list":
            url = self.state['config']['payroll']['nd_list_url']
            self.log.info(f"Opening Night Differential List: {url}")
            webbrowser.open(url)  

        else:
            self.log.warning(f"Unhandled button: {btn}")

    def _handle_header_clicks(self, btn):
        if btn == 'close':
            self.main_window.close()
            self._file_manager.upload_log(self.state)
        if btn == 'minimized':
            self.main_window.showMinimized()
        if btn == "restart":
            pass
    # ===================================================================
    # ENTRY POINT
    # ===================================================================

    def start(self):
        self.log.info("Checking internet connectivity...")

        if internet_available():
            self.log.info("Internet available — showing login")
            self.body.show_login()
        else:
            self.log.warning("No internet connection — showing no-internet screen")
            self.body.show_no_internet()

    # ===================================================================
    # LOGIN FLOW
    # ===================================================================

    def _login(self):
        self.log.info("Login button clicked — starting MSAL login")

        if not self._msal:
            self._msal = MSALService(self.log)
            self._msal.on_login_complete = self._on_login_complete
            self._msal.on_device_code    = self._on_device_code
            self._msal.error_login       = self._on_login_error

        self._msal.start_login()

    def _on_device_code(self, payload):
        self.log.info(f"Device code issued: {payload.get('user_code')} — opening browser for auth")
        self.body.update_login_form("device_code", payload)

    def _on_login_error(self, error):
        self.log.warning(f"Login failed: {error}")
        self.body.update_login_form("login_error", error)

    def _on_login_complete(self, email, name, token):
        self.log.info(f"Login successful — user: {name} ({email})")

        self.state.update({
            "email":     email,
            "name":      name,
            "token":     token,
            "logged_in": True,
        })

        self._sharepoint = SharePointService(token)
        self._load_config()

    # ===================================================================
    # CONFIG LOAD
    # ===================================================================

    def _load_config(self):
        self.log.info("Fetching config from SharePoint...")

        self._config = ConfigService()

        try:
           response =self._config.get(self.state['token'])
        except Exception as e:
            self.log.warning(f"Config request failed: {e}", error=e)
            self.body.update_login_form("config_error")
            return

        try:
            config = json.loads(response.text)
            self.state["config"] = config
            self.log.info("Config loaded and parsed successfully")

            if self.state['email'] in self.state['config']['users']:
                self.log.info(f"Access granted — {self.state['name']} ({self.state['email']})")
                self.body.show_sources()
                raise
            else:
                self.log.warning(f"Access denied — {self.state['name']} ({self.state['email']}) is not in the allowed users list")
                self.body.update_login_form("restricted_user")

        except Exception as e:
            self.log.warning(f"Config JSON parse failed: {e}", error=e)
            self.body.update_login_form("json_error")

    # ===================================================================
    # NAVIGATION
    # ===================================================================

    def _on_source_selected(self, source):
        clean_source = source.replace("_source", "")
        self.log.info(f"Source selected: {clean_source}")
        self.state["source"] = clean_source
        self.body.show_features()

    def _on_feature_selected(self, feature):
        self.log.info(f"Feature selected: {feature} (source: {self.state['source']})")
        self.state["feature"] = feature

        # Feature requirements from config
        required_files = self.state['config']['payroll']['required_files']
        users = self.state['config']['users']
        deminimis = self.state['config']['deminimis']

        if feature == "payroll_feature":
            self.log.info(f"Loading payroll feature — {len(required_files)} required file(s)")
            self.body.show_payroll_feature(required_files)

        elif feature == "checker_feature":
            self.log.info("Loading checker feature")
            self.body.show_checker_feature()

        elif feature == "settings_feature":
            self.log.info(f"Loading settings feature — {len(users)} user(s), {len(deminimis)} deminimis item(s)")
            self.body.show_settings_feature(users, deminimis)

    # ===================================================================
    # PAYROLL MAIN FLOW
    # ===================================================================

    def _on_payroll_upload_clicked(self):
        self.log.info("Payroll upload initiated")

        # Set default folder name (no versioning override)
        self.state['folder_name'] = f"{self.state['month_year']}/{self.state['id']}/{self.state['version']}/input"
        self.log.info(f"Default folder path set: {self.state['folder_name']}")

        # Run versioning checks if inputs were provided
        if self.inputs['id'] or self.inputs['version']:
            self.log.info("Custom ID/Version inputs detected — running version checks")
            version_status = self._id_version_checks()

            if version_status:  # Error found
                self.log.warning(f"Version check failed with: {version_status}")
                self.body.show_payroll_status(version_status)
                return

        # Payroll feature requirements
        expected_files    = self.state['config']['payroll']['required_files']
        payroll_metadata  = self.state['config']['payroll']
        source = self.state['source']
        token  = self.state['token']

        self.log.info(f"Starting file upload handler — source: {source} | expected files: {expected_files}")
        self.payroll.prepare_payroll_files(expected_files, payroll_metadata, source, token)

    def _payroll_files_preparation_result(self, codes):
        self.log.info(f"Payroll files preparation results — {len(codes)} status code(s): {codes}")

        for code in codes:
            file_name, status_code = parse_status_code(code)
            message_template = PAYROLL_STATUSES.get(status_code, status_code)
            message = message_template.format(file_name=file_name or "")

            if "error" in status_code:
                self.log.warning(f"[PAYROLL UPLOAD RESULT] {message}")
            else:
                self.log.info(f"[PAYROLL UPLOAD RESULT] {message}")

        # Update UI with statuses
        self.body.show_payroll_status(codes)

    def _id_version_checks(self):
        self.log.info("Running ID/Version validation")

        def _found_folder(name, folders):
            return any(folder["name"] == name for folder in folders)

        # Input validation
        if self.inputs['id'] and not self.inputs['version']:
            self.log.warning("Version missing — ID provided without version")
            return ["version_missing_error"]

        elif not self.inputs['id'] and self.inputs['version']:
            self.log.warning("ID missing — version provided without ID")
            return ['id_missing_error']

        # Normalize version string
        if self.inputs['version'].isdigit():
            self.version = f"v{self.inputs['version']}"
        elif re.fullmatch(r"v\d+", self.inputs['version']):
            self.version = self.inputs['version']
        else:
            self.log.warning(f"Invalid version format: '{self.inputs['version']}'")
            return ["version_input_error"]

        self.log.info(f"Normalized version: {self.version}")

        # Common folder root
        payroll_folder = self.state['config']['payroll']['folder']

        # Validate ID folder exists in SharePoint
        url = f"{self.SP_BASE_URL}root:/{payroll_folder}/{self.state['month_year']}:/children"
        self.log.info(f"Checking SharePoint for ID folder — month: {self.state['month_year']}")

        response = self._sharepoint.get(url)
        sp_id_folder_list = response.json().get("value", [])

        if not _found_folder(self.inputs['id'], sp_id_folder_list):
            self.log.warning(f"ID folder not found in SharePoint: '{self.inputs['id']}'")
            return ['id_error']

        self.log.info(f"ID folder found: '{self.inputs['id']}'")

        # Validate version folder is not a duplicate
        url = f"{self.SP_BASE_URL}root:/{payroll_folder}/{self.state['month_year']}/{self.inputs['id']}:/children"
        self.log.info(f"Checking SharePoint for duplicate version folder: {self.version}")

        response = self._sharepoint.get(url)
        sp_version_folder_list = response.json().get("value", [])

        if _found_folder(self.version, sp_version_folder_list):
            self.log.warning(f"Version folder already exists: '{self.version}' under ID '{self.inputs['id']}'")
            return ['version_duplicate_error']

        # Accept inputs as state
        self.state['id'] = self.inputs['id']
        self.state['version'] = self.inputs['version']
        self.state['folder_name'] = f"{self.state['month_year']}/{self.state['id']}/{self.state['version']}/input"

        self.log.info(f"ID/Version validation passed — folder path: {self.state['folder_name']}")
        return []

    def _upload_sp_files(self, files):
        folder   = self.state['config']['payroll']['folder'] + self.state['folder_name']
        base_url = f"{self.SP_BASE_URL}root:/{folder}"

        self.log.info(f"Uploading {len(files)} file(s) to SharePoint folder: {folder}")

        upload_errors = []

        for filename, content in files.items():
            csv_buffer = io.StringIO()
            content.to_csv(csv_buffer, index=False)
            file_name = f"{filename}_{self.state['id']}_{self.state['version']}.csv"
            url = f"{base_url}/{file_name}:/content"

            self.log.info(f"Uploading: {file_name}")
            response = self._sharepoint.put_file(url, data=csv_buffer, content_type="text/csv")

            if not str(response.status_code).startswith("2"):
                self.log.warning(f"Upload failed for '{file_name}' — HTTP {response.status_code}")
                upload_errors.append(filename)

        if upload_errors:
            self.log.warning(f"SharePoint upload failed for: {upload_errors}")
            self.body.show_payroll_status(['upload_sp_error'])
            return

        self.log.info(f"All files uploaded successfully — ID: {self.state['id']} | Version: {self.state['version']}")
        self.body.show_payroll_status(["file_success"])

    def _start_unmand(self):
        API_TOKEN   = self.state['config']["unmand"]["token"]
        webhook_url = self.state['config']['unmand']['webhook']

        self.log.info(f"Initialising Unmand service")
        self._unmand = UnmandService(webhook_url, API_TOKEN)

        # Get non-payroll files
        other_files = [
            f for f in self.state['config']['payroll']['required_files']
            if "payroll" not in f and "attendance" not in f
        ]
        self.log.info(f"Other files to include in payload: {other_files}")

        PAYLOAD = {
            "local_app": {
                "id":          self.state['id'],
                "version":     self.state['version'],
                "folder_name": self.state['folder_name'],
                "userEmail":   self.state['email'],
                "userName":    self.state['name'],
                "month_year":  self.state['month_year'],
                "other_files": other_files,
                "source_type": self.state['source']
            },
            "status":  {},
            "process": "payroll"
        }

        self.log.info(f"Sending Unmand payload — ID: {self.state['id']} | Version: {self.state['version']} | Source: {self.state['source']}")
        response = self._unmand.start_process(PAYLOAD)

        if not str(response.status_code).startswith("2"):
            self.log.warning(f"Unmand start failed — HTTP {response.status_code}")
            self.body.show_payroll_status(['unmand_init_error'])
        else:
            self.state['guid'] = json.loads(response.text)['taskGuid']
            id_version = f"ID: {self.state['id']} Version: {self.state['version']} Source: {self.state['source']}"
            self.log.info(f"Unmand started successfully — GUID: {self.state['guid']}")
            self.body.show_payroll_status([f'{id_version}|unmand_init_success'])

    def _check_unmand(self):
        self.log.info(f"Checking Unmand status — GUID: {self.state.get('guid')}")
        status = self._unmand.check_status(self.state['guid'])
        self.log.info(f"Unmand status response: {status}")

        if "success" in status:
            status = f"{status}|ID: {self.state['id']} - Version: {self.state['version']}"

        self.body.show_payroll_status([status])

    # ===================================================================
    # CHECKER MAIN FLOW
    # ===================================================================

    def _checker_files_preparation_result(self, codes):
        self.log.info(f"Checker files preparation results — {len(codes)} status code(s): {codes}")

        for code in codes:
            file_name, status_code = parse_status_code(code)
            message_template = CHECKER_STATUSES.get(status_code, status_code)
            message = message_template.format(file_name=file_name or "")

            if "error" in status_code:
                self.log.warning(f"[CHECKER UPLOAD RESULT] {message}")
            else:
                self.log.info(f"[CHECKER UPLOAD RESULT] {message}")

        # Update UI with statuses
        self.body.show_checker_status(codes)

    def _generate_validation(self, files):

        base_url    = os.getenv("SP_BASE_URL")
        headers_loc = self.state['config']['payroll']['headers_loc']
        url         = f"{base_url}{headers_loc}"

        self.log.info(f"Downloading payroll headers from SharePoint")
        response = self._sharepoint.get(url)

        if not str(response.status_code).startswith("2"):
            self.log.warning(f"Headers download failed — HTTP {response.status_code}")
            self.body.show_checker_status(['premium_download_error'])
            return
        else:
            excel_file = io.BytesIO(response.content)
            if self.state['source'] == "Sprout":
                df = pd.read_excel(excel_file, sheet_name="Sprout Checker", header=12, engine="openpyxl")  # row 13
            else:
                df = pd.read_excel(excel_file, sheet_name="DarwinBox Checker", header=12, engine="openpyxl")  # row 13

            headers = list(df['Payroll Headers'])
    

        manual_df = None
        unmand_df = None

        # ---------------------------
        # LOAD FILES
        # ---------------------------
        for filename, df in files.items():
            if "manual" in filename.lower():
                manual_df = df
            elif "unmand" in filename.lower():
                unmand_df = df

        # ---------------------------
        # SAFE DEFAULTS
        # ---------------------------
        if manual_df is None:
            manual_df = pd.DataFrame()

        if unmand_df is None:
            unmand_df = pd.DataFrame()

        # ---------------------------
        # HELPER: GET TOTALS
        # ---------------------------
        def _get_totals(df):
            totals = {}

            if isinstance(df, pd.DataFrame) and "Employee ID" in df.columns:
                total_row = df[df["Employee ID"].astype(str).str.lower().str.contains("total")]

                if not total_row.empty:
                    total_row = total_row.iloc[0]

                    for h in headers:
                        totals[h] = total_row[h] if h in df.columns else 0
                else:
                    totals = {h: 0 for h in headers}
            else:
                totals = {h: 0 for h in headers}

            return totals

        # ---------------------------
        # SUMMARY TOTALS
        # ---------------------------
        manual_totals = _get_totals(manual_df)
        unmand_totals = _get_totals(unmand_df)

        # ---------------------------
        # SUMMARY OUTPUT TABLE
        # ---------------------------
        var_tolerance = self.state['config']["var_tolerance"]
        output = []

        for h in headers:

            manual_val = pd.to_numeric(manual_totals.get(h, 0), errors="coerce")
            unmand_val = pd.to_numeric(unmand_totals.get(h, 0), errors="coerce")

            manual_val = 0 if pd.isna(manual_val) else manual_val
            unmand_val = 0 if pd.isna(unmand_val) else unmand_val

            output.append({
                "Payroll Header": h,
                "Manual Checker": manual_val,
                "Unmand Checker": unmand_val,
                "Variance": manual_val - unmand_val
            })

        output_df = pd.DataFrame(output)


        # ---------------------------
        # DETAILED VARIANCE (NEW SHEET)
        # ---------------------------
        id_col = "Employee ID"

        detailed = pd.DataFrame()

        if isinstance(manual_df, pd.DataFrame) and isinstance(unmand_df, pd.DataFrame):

            manual_cols = [h for h in headers if h in manual_df.columns]
            unmand_cols = [h for h in headers if h in unmand_df.columns]

            manual_long = manual_df.melt(
                id_vars=[id_col],
                value_vars=manual_cols,
                var_name="Payroll Header",
                value_name="Manual Value"
            )

            unmand_long = unmand_df.melt(
                id_vars=[id_col],
                value_vars=unmand_cols,
                var_name="Payroll Header",
                value_name="Unmand Value"
            )

            detailed = pd.merge(
                manual_long,
                unmand_long,
                on=["Employee ID", "Payroll Header"],
                how="outer"
            )

            # Convert safely
            detailed["Manual Value"] = pd.to_numeric(detailed["Manual Value"], errors="coerce").fillna(0)
            detailed["Unmand Value"] = pd.to_numeric(detailed["Unmand Value"], errors="coerce").fillna(0)

            detailed["Variance"] = detailed["Manual Value"] - detailed["Unmand Value"]


        # ---------------------------
        # FILE PATH
        # ---------------------------
        folder_path = app_data_path() / "data" / "validation"
        folder_path.mkdir(parents=True, exist_ok=True)

        file_path = folder_path / f"Checker_Variance_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"

        self.state['variance_file'] = file_path

        # ---------------------------
        # METRICS
        # ---------------------------
        today = datetime.now().strftime("%Y-%m-%d")

        manual_count = len(manual_df)
        unmand_count = len(unmand_df)

        accuracy = (
            (output_df["Variance"].abs() >= var_tolerance).sum() / len(output_df)
            if len(output_df) > 0 else 0
        )


        # ---------------------------
        # WRITE EXCEL
        # ---------------------------
        with pd.ExcelWriter(file_path, engine="openpyxl") as writer:

            # -----------------------
            # SUMMARY SHEET
            # -----------------------
            meta_df = pd.DataFrame({
                "Info": [
                    "Date",
                    "Manual Rows",
                    "Unmand Rows",
                    "Accuracy Rate",
                    "Tolerance"
                ],
                "Value": [
                    today,
                    manual_count,
                    unmand_count,
                    round((1 - accuracy) * 100, 2),
                    f"± {var_tolerance}"
                ]
            })

            meta_df.to_excel(
                writer,
                sheet_name="Variance Report",
                index=False,
                startrow=0
            )

            output_df.to_excel(
                writer,
                sheet_name="Variance Report",
                index=False,
                startrow=7
            )

            # -----------------------
            # DETAILED SHEET
            # -----------------------
            if not detailed.empty:
                detailed.to_excel(
                    writer,
                    sheet_name="Detailed Variance",
                    index=False
                )


        # ---------------------------
        # UI UPDATES
        # ---------------------------
        self.log.info("Checker variance file generated")
        self.body.show_checker_status(['validated_success'])

    # ===================================================================
    # SETTINGS MAIN FLOW
    # ===================================================================

    def _save_deminimis(self, deminimis):
        current_deminimis = self.state['config']['deminimis']
        new_deminimis = {}

        for key, val in deminimis.items():
            if val:
                try:
                    new_deminimis[key] = float(val)
                except:
                    self.body.show_settings_save_deminimis_status(['deminimis_save_error'])
                    return

            else:
                new_deminimis[key] = current_deminimis[key]

        # Save updated values
        self.state["config"]["deminimis"] = new_deminimis

        response = self._config.update(self.state['config'], self.state['token'])

        if not str(response.status_code).startswith("2"):
                self.body.show_settings_save_deminimis_status(['deminimis_save_error'])
                return
        
        self.body.show_settings_save_deminimis_status(['deminimis_save_success'])
            

    def _add_user(self, email):
        if not email:
            self.body.show_settings_add_user_status(['empty_error'])

        elif "@intogreatsolutions.com" not in email:
            self.body.show_settings_add_user_status(['error_email'])

        elif email in self.state['config']['users']:
            self.body.show_settings_add_user_status(['duplicate_user'])

        else:

            # Requirements for the power automate flow
            FLOW_URL = rf"{self.state['config']['entra']['flow_url']}"
            payload = {
                "UserEmail": email,
                "GroupID": self.state['config']["entra"]["teams_group"],
                "GroupName": os.getenv('app')
            }

            power_automate = PowerAutomateService()

            response = power_automate.start(FLOW_URL, payload=payload)

            if not str(response.status_code).startswith("2"):
                self.body.show_settings_add_user_status(['add_user_error'])
                return
            
            # Requirements for the welcome email 
            EMAIL_URL = "https://graph.microsoft.com/v1.0/me/sendMail"
            payload = {
                    "message": {
                        "subject": "Welcome to Payroll Automation App🎉",
                        "body": {
                            "contentType": "HTML",
                            "content": WELCOME_EMAIL.format(user=self.state['name'])
                        },
                        "toRecipients": [
                            {
                                "emailAddress": {
                                    "address": email
                                }
                            }
                        ]
                    }
                }
            
            outlook = OutlookService()

            response = outlook.send(EMAIL_URL, payload=payload, token=self.state['token'])
            
            if not str(response.status_code).startswith("2"):
                self.body.show_settings_add_user_status(['add_user_email_error'])
                return
            
            self.state['config']['users'].append(email)
            self._config.update(self.state['config'], self.state['token'])
            self.body.show_settings_add_user_status(['add_user_success'])
                  


                

